#ifndef __BASE64_H__
#define __BASE64_H__
int base64enc(char *, size_t, char *, size_t *);
int base64dec(char *, size_t, char *, size_t *);
#endif				/* __BASE64_H__ */
